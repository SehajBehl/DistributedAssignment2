import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.List;
import java.util.Scanner;

public class LibraryClient {
    public static void main(String[] args) {
        try {
            Registry registry = LocateRegistry.getRegistry("localhost", 1099);
            LibraryService libraryService = (LibraryService) registry.lookup("LibraryService");
            Scanner scanner = new Scanner(System.in);

            while (true) {
                System.out.println("\nLibrary Management System");
                System.out.println("1. View all books");
                System.out.println("2. Borrow a book");
                System.out.println("3. Return a book");
                System.out.println("4. Search books");
                System.out.println("5. Rate a book");
                System.out.println("6. Get recommendations by genre");
                System.out.println("7. Exit");
                System.out.print("Enter your choice (1-7): ");

                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline

                switch (choice) {
                    case 1:
                        System.out.println(libraryService.viewBooks());
                        break;

                    case 2:
                        System.out.print("Enter book name to borrow: ");
                        String borrowBook = scanner.nextLine();
                        System.out.println(libraryService.borrowBook(borrowBook));
                        break;

                    case 3:
                        System.out.print("Enter book name to return: ");
                        String returnBook = scanner.nextLine();
                        System.out.println(libraryService.returnBook(returnBook));
                        break;

                    case 4:
                        System.out.print("Enter search term: ");
                        String searchTerm = scanner.nextLine();
                        System.out.println(libraryService.searchBooks(searchTerm));
                        break;

                    case 5:
                        System.out.print("Enter book name to rate: ");
                        String bookToRate = scanner.nextLine();
                        System.out.print("Enter rating (1-5): ");
                        int rating = scanner.nextInt();
                        System.out.println(libraryService.rateBook(bookToRate, rating));
                        break;

                    case 6:
                        System.out.print("Enter genre (Fantasy/Science Fiction/Mystery): ");
                        String genre = scanner.nextLine();
                        List<String> recommendations = libraryService.getRecommendations(genre);
                        System.out.println("Recommended books in " + genre + ":");
                        for (String book : recommendations) {
                            System.out.println("- " + book);
                        }
                        break;

                    case 7:
                        System.out.println("Thank you for using the Library Management System!");
                        System.exit(0);

                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }
        } catch (Exception e) {
            System.err.println("Client exception: " + e.toString());
            e.printStackTrace();
        }
    }
}