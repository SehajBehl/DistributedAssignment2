// LibraryService.java
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;

public interface LibraryService extends Remote {
    String viewBooks() throws RemoteException;
    String borrowBook(String bookName) throws RemoteException;
    String returnBook(String bookName) throws RemoteException;
    String searchBooks(String searchTerm) throws RemoteException;
    // New methods
    String rateBook(String bookName, int rating) throws RemoteException;
    List<String> getRecommendations(String genre) throws RemoteException;
}