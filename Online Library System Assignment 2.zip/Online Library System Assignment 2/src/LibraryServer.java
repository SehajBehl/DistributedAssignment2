import java.rmi.RemoteException;
import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.UnicastRemoteObject;
import java.util.*;

public class LibraryServer implements LibraryService {
    private Map<String, Integer> books;
    private Map<String, List<Integer>> bookRatings;
    private Map<String, String> bookGenres;

    public LibraryServer() {
        books = new HashMap<>();
        books.put("The Lord of the Rings", 1);
        books.put("Harry Potter", 1);
        books.put("The Hunger Games", 1);
        books.put("The Witcher", 1);
        books.put("The Divergent", 1);
        books.put("Sherlock Holmes", 1);

        bookRatings = new HashMap<>();

        bookGenres = new HashMap<>();
        bookGenres.put("The Lord of the Rings", "Fantasy");
        bookGenres.put("Harry Potter", "Fantasy");
        bookGenres.put("The Hunger Games", "Science Fiction");
        bookGenres.put("The Witcher", "Fantasy");
        bookGenres.put("The Divergent", "Science Fiction");
        bookGenres.put("Sherlock Holmes", "Mystery");
    }

    @Override
    public synchronized String viewBooks() throws RemoteException {
        return books.toString();
    }

    @Override
    public synchronized String borrowBook(String bookName) throws RemoteException {
        if (books.containsKey(bookName) && books.get(bookName) > 0) {
            books.put(bookName, books.get(bookName) - 1);
            return "You have borrowed the book: \"" + bookName + "\"";
        }
        return "\"" + bookName + "\" is not available right now";
    }

    @Override
    public synchronized String returnBook(String bookName) throws RemoteException {
        if (books.containsKey(bookName)) {
            books.put(bookName, books.get(bookName) + 1);
            return "You have returned the book: \"" + bookName + "\"";
        }
        return "\"" + bookName + "\" does not belong to this library";
    }

    @Override
    public synchronized String searchBooks(String searchTerm) throws RemoteException {
        StringBuilder sb = new StringBuilder();
        sb.append("Search Results for \"").append(searchTerm).append("\": ");
        boolean first = true;
        for (String book : books.keySet()) {
            if (book.toLowerCase().contains(searchTerm.toLowerCase())) {
                if (!first) {
                    sb.append(" | ");
                }
                int available = books.get(book);
                sb.append(book).append(" - Available: ").append(available);
                first = false;
            }
        }
        if (first) {
            sb.append("No books found matching the search term.");
        }
        return sb.toString();
    }

    @Override
    public synchronized String rateBook(String bookName, int rating) throws RemoteException {
        if (!books.containsKey(bookName)) {
            return "Book not found in library.";
        }
        if (rating < 1 || rating > 5) {
            return "Rating must be between 1 and 5.";
        }

        bookRatings.computeIfAbsent(bookName, k -> new ArrayList<>()).add(rating);

        double avgRating = bookRatings.get(bookName).stream()
                .mapToInt(Integer::intValue)
                .average()
                .orElse(0.0);

        return String.format("Thank you for rating \"%s\". Current average rating: %.1f/5.0",
                bookName, avgRating);
    }

    @Override
    public synchronized List<String> getRecommendations(String genre) throws RemoteException {
        List<String> recommendations = new ArrayList<>();

        for (Map.Entry<String, String> entry : bookGenres.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(genre) && books.get(entry.getKey()) > 0) {
                recommendations.add(entry.getKey());
            }
        }

        return recommendations;
    }

    public static void main(String[] args) {
        try {
            LibraryServer server = new LibraryServer();
            LibraryService stub = (LibraryService) UnicastRemoteObject.exportObject(server, 0);

            Registry registry = LocateRegistry.createRegistry(1099);
            registry.bind("LibraryService", stub);

            System.out.println("Library Server is running...");
        } catch (Exception e) {
            System.err.println("Server exception: " + e.toString());
            e.printStackTrace();
        }
    }
}